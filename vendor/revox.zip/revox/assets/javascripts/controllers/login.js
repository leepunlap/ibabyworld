app.controller('LoginController', function ($rootScope, $scope, $state, $stateParams, $http, Data, AuthService) {
    $scope.doLogin = function (user) {
        $scope.submitted = true;
        $scope.success = true;

        if (!$scope.loginForm.$invalid) {
            console.log('Loggin in!');

            AuthService.login(user).then(function (user) {
                if (user == null) {
                    $scope.user.password = '';
                    $scope.success = false;

                } else {
                    $rootScope.isAuthorized = AuthService.isAuthorized();
                    $rootScope.loggedUser = user;
                    $state.go('dashboard');
                }

                console.log('Check Authorization: '+ $rootScope.isAuthorized);
            });
        }
    };
});