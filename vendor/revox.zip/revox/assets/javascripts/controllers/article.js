app.controller('ArticleController', function ($rootScope, $scope, $state, $stateParams, $http, Data, Articles) {
    $scope.articles = null;

    console.log('Scope name: '+ $rootScope.$state.name);
    
    if ($rootScope.$state.name == "articles") {
        // Get articles
        Data.get(requestPath.articles).then(function (results) {
            if (results.code == 200) {
                console.log('Article response code: '+ results.code);

                $scope.articles = results.body.articles;
            }
        });

    } else if ($rootScope.$state.name == "articles-edit") {
        // Get article details
        $scope.articleId = $stateParams.id;        

        console.log('Get article Id: '+ $scope.articleId);

        Data.get(requestPath.articles +'/'+ $scope.articleId).then(function (results) {

            if (results.code == 200) {
                $scope.article = results.body.article;
            }
        });
    }


    $scope.doNewArticle = function () {
        $state.go('articles-new')
    }

    $scope.doUpdateArticle = function (article) {
        $scope.submitted = true;
    
        if (!$scope.articleForm.$invalid) {
            Data.post(requestPath.articles +'/'+ $scope.articleId +'/update', {
                article: article

            }).then(function (results) {
                if (results.code == 200) {
                    $state.go('articles');
                    
                    // $.each(body.member, function(key, value){
                    //     console.log('Parameters: '+ key +' : '+ value);
                    // });

                    console.log('success registration!');

                }
            });
        }
    };

    $scope.doCreateArticle = function (article) {
        $scope.submitted = true;
    
        if (!$scope.articleForm.$invalid) {
            Data.post(requestPath.articles +'/create', {
                article: article

            }).then(function (results) {
                if (results.code == 200) {
                    $state.go('articles');
                    
                    // $.each(body.member, function(key, value){
                    //     console.log('Parameters: '+ key +' : '+ value);
                    // });

                    console.log('success registration!');

                }
            });
        }
    };
});